//DOM就绪后执行
$(document).ready(function(){

	//定义索引：tab页签li与内容div的索引一一对应
	var index;

	//定义定时器对象
	var timeId = null;

	//tab页签li与内容div的jQuery对象变量
	var $lis = $(".notice-hd li");
	var $divs = $(".notice-bd div");

	//为每个tab页签li绑定鼠标滑过事件
	$lis.on("mouseover", function(){

		//保存当前li对象
		$that = $(this);

		//如果存在准备执行的定时器，立刻清除，只有当前停留时间大于500毫秒才执行
		if(timeId){
			clearTimeout(timeId);
			timeId = null;
		}

		//延迟半秒执行
		timeId = setTimeout(function(){

			//获得当前tab页签的索引
			index = $that.index();

			//设置当前tab页签高亮显示
			$that.addClass("selected").siblings().removeClass("selected");

			//设置对应的内容div显示
			$divs.eq(index).show().siblings().hide();

		},500);

	});
});